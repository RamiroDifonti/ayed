#include <iostream>


int main(){



    int a{0},b{0},c{0};
    if(a+1==1){
       std::cout<<"si"<<a;
    }
    std::cout<<a;

  return 0;
}